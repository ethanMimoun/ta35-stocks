export default function Home() {
  return (
    <iframe 
      src="/index.html" 
      className="fixed inset-0 w-full h-full border-0"
      title="Israeli Bourse - Stock Market App"
    />
  )
}
