"use client"

import { useEffect, useRef, useCallback } from "react"

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  size: number
  opacity: number
  color: string
}

interface ChartPoint {
  x: number
  y: number
  targetY: number
}

interface GridLine {
  y: number
  opacity: number
  speed: number
}

interface DataStream {
  x: number
  y: number
  length: number
  speed: number
  opacity: number
}

export function FintechBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>(0)
  const particlesRef = useRef<Particle[]>([])
  const chartPointsRef = useRef<ChartPoint[]>([])
  const gridLinesRef = useRef<GridLine[]>([])
  const dataStreamsRef = useRef<DataStream[]>([])
  const timeRef = useRef(0)

  const colors = {
    navy: "#0a1628",
    deepNavy: "#050d1a",
    steel: "#1e293b",
    cyan: "#06b6d4",
    electricBlue: "#0ea5e9",
    darkCyan: "#0891b2",
    accent: "#22d3ee",
  }

  const initializeElements = useCallback((width: number, height: number) => {
    // Initialize particles
    const particles: Particle[] = []
    const particleCount = Math.floor((width * height) / 15000)
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.5 + 0.5,
        opacity: Math.random() * 0.4 + 0.1,
        color: Math.random() > 0.7 ? colors.cyan : colors.electricBlue,
      })
    }
    particlesRef.current = particles

    // Initialize chart wave points
    const chartPoints: ChartPoint[] = []
    const pointCount = Math.ceil(width / 30)
    for (let i = 0; i <= pointCount; i++) {
      const x = (i / pointCount) * width
      const baseY = height * 0.6
      chartPoints.push({
        x,
        y: baseY,
        targetY: baseY,
      })
    }
    chartPointsRef.current = chartPoints

    // Initialize horizontal grid lines
    const gridLines: GridLine[] = []
    const gridCount = 12
    for (let i = 0; i < gridCount; i++) {
      gridLines.push({
        y: (i / gridCount) * height,
        opacity: Math.random() * 0.08 + 0.02,
        speed: Math.random() * 0.2 + 0.1,
      })
    }
    gridLinesRef.current = gridLines

    // Initialize data streams (vertical flowing lines)
    const dataStreams: DataStream[] = []
    const streamCount = Math.floor(width / 80)
    for (let i = 0; i < streamCount; i++) {
      dataStreams.push({
        x: Math.random() * width,
        y: Math.random() * height * 2 - height,
        length: Math.random() * 100 + 50,
        speed: Math.random() * 1 + 0.5,
        opacity: Math.random() * 0.15 + 0.05,
      })
    }
    dataStreamsRef.current = dataStreams
  }, [colors.cyan, colors.electricBlue])

  const draw = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    timeRef.current += 0.016

    // Clear with deep navy gradient
    const gradient = ctx.createLinearGradient(0, 0, width, height)
    gradient.addColorStop(0, colors.deepNavy)
    gradient.addColorStop(0.5, colors.navy)
    gradient.addColorStop(1, "#030712")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw subtle radial glow in center
    const radialGradient = ctx.createRadialGradient(
      width * 0.5,
      height * 0.4,
      0,
      width * 0.5,
      height * 0.4,
      width * 0.6
    )
    radialGradient.addColorStop(0, "rgba(6, 182, 212, 0.03)")
    radialGradient.addColorStop(0.5, "rgba(14, 165, 233, 0.015)")
    radialGradient.addColorStop(1, "transparent")
    ctx.fillStyle = radialGradient
    ctx.fillRect(0, 0, width, height)

    // Draw grid lines (horizontal)
    gridLinesRef.current.forEach((line) => {
      line.y += line.speed
      if (line.y > height) {
        line.y = 0
        line.opacity = Math.random() * 0.08 + 0.02
      }

      ctx.beginPath()
      ctx.strokeStyle = `rgba(30, 41, 59, ${line.opacity})`
      ctx.lineWidth = 1
      ctx.moveTo(0, line.y)
      ctx.lineTo(width, line.y)
      ctx.stroke()
    })

    // Draw vertical grid lines (static)
    const vGridCount = Math.floor(width / 60)
    for (let i = 0; i <= vGridCount; i++) {
      const x = (i / vGridCount) * width
      const opacity = 0.03 + Math.sin(timeRef.current * 0.5 + i * 0.3) * 0.02
      ctx.beginPath()
      ctx.strokeStyle = `rgba(30, 41, 59, ${opacity})`
      ctx.lineWidth = 1
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }

    // Draw data streams
    dataStreamsRef.current.forEach((stream) => {
      stream.y += stream.speed
      if (stream.y > height + stream.length) {
        stream.y = -stream.length
        stream.x = Math.random() * width
        stream.opacity = Math.random() * 0.15 + 0.05
      }

      const streamGradient = ctx.createLinearGradient(stream.x, stream.y, stream.x, stream.y + stream.length)
      streamGradient.addColorStop(0, "transparent")
      streamGradient.addColorStop(0.3, `rgba(6, 182, 212, ${stream.opacity})`)
      streamGradient.addColorStop(0.7, `rgba(14, 165, 233, ${stream.opacity * 0.7})`)
      streamGradient.addColorStop(1, "transparent")

      ctx.beginPath()
      ctx.strokeStyle = streamGradient
      ctx.lineWidth = 1
      ctx.moveTo(stream.x, stream.y)
      ctx.lineTo(stream.x, stream.y + stream.length)
      ctx.stroke()
    })

    // Update and draw chart wave
    chartPointsRef.current.forEach((point, i) => {
      // Smooth wave motion
      const wave1 = Math.sin(timeRef.current * 0.8 + i * 0.15) * 30
      const wave2 = Math.sin(timeRef.current * 0.5 + i * 0.1) * 20
      const wave3 = Math.sin(timeRef.current * 1.2 + i * 0.2) * 10
      point.targetY = height * 0.55 + wave1 + wave2 + wave3
      point.y += (point.targetY - point.y) * 0.08
    })

    // Draw chart area fill
    ctx.beginPath()
    ctx.moveTo(0, height)
    chartPointsRef.current.forEach((point, i) => {
      if (i === 0) {
        ctx.lineTo(point.x, point.y)
      } else {
        const prev = chartPointsRef.current[i - 1]
        const cpX = (prev.x + point.x) / 2
        ctx.quadraticCurveTo(prev.x, prev.y, cpX, (prev.y + point.y) / 2)
        if (i === chartPointsRef.current.length - 1) {
          ctx.quadraticCurveTo(cpX, (prev.y + point.y) / 2, point.x, point.y)
        }
      }
    })
    ctx.lineTo(width, height)
    ctx.closePath()

    const areaGradient = ctx.createLinearGradient(0, height * 0.3, 0, height)
    areaGradient.addColorStop(0, "rgba(6, 182, 212, 0.08)")
    areaGradient.addColorStop(0.5, "rgba(14, 165, 233, 0.04)")
    areaGradient.addColorStop(1, "transparent")
    ctx.fillStyle = areaGradient
    ctx.fill()

    // Draw chart line
    ctx.beginPath()
    chartPointsRef.current.forEach((point, i) => {
      if (i === 0) {
        ctx.moveTo(point.x, point.y)
      } else {
        const prev = chartPointsRef.current[i - 1]
        const cpX = (prev.x + point.x) / 2
        ctx.quadraticCurveTo(prev.x, prev.y, cpX, (prev.y + point.y) / 2)
        if (i === chartPointsRef.current.length - 1) {
          ctx.quadraticCurveTo(cpX, (prev.y + point.y) / 2, point.x, point.y)
        }
      }
    })
    ctx.strokeStyle = `rgba(6, 182, 212, 0.4)`
    ctx.lineWidth = 1.5
    ctx.stroke()

    // Draw second chart wave (offset)
    ctx.beginPath()
    chartPointsRef.current.forEach((point, i) => {
      const offsetY = point.y + 80 + Math.sin(timeRef.current * 0.6 + i * 0.12) * 15
      if (i === 0) {
        ctx.moveTo(point.x, offsetY)
      } else {
        const prev = chartPointsRef.current[i - 1]
        const prevOffsetY = prev.y + 80 + Math.sin(timeRef.current * 0.6 + (i - 1) * 0.12) * 15
        const cpX = (prev.x + point.x) / 2
        ctx.quadraticCurveTo(prev.x, prevOffsetY, cpX, (prevOffsetY + offsetY) / 2)
      }
    })
    ctx.strokeStyle = `rgba(14, 165, 233, 0.25)`
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw particles
    particlesRef.current.forEach((particle) => {
      particle.x += particle.vx
      particle.y += particle.vy

      // Wrap around edges
      if (particle.x < 0) particle.x = width
      if (particle.x > width) particle.x = 0
      if (particle.y < 0) particle.y = height
      if (particle.y > height) particle.y = 0

      // Subtle pulse
      const pulse = Math.sin(timeRef.current * 2 + particle.x * 0.01) * 0.1 + 1

      ctx.beginPath()
      ctx.arc(particle.x, particle.y, particle.size * pulse, 0, Math.PI * 2)
      ctx.fillStyle = particle.color.replace(")", `, ${particle.opacity})`)
        .replace("rgb", "rgba")
        .replace("#06b6d4", `rgba(6, 182, 212, ${particle.opacity})`)
        .replace("#0ea5e9", `rgba(14, 165, 233, ${particle.opacity})`)
      
      // Handle hex colors
      if (particle.color === colors.cyan) {
        ctx.fillStyle = `rgba(6, 182, 212, ${particle.opacity * pulse})`
      } else {
        ctx.fillStyle = `rgba(14, 165, 233, ${particle.opacity * pulse})`
      }
      ctx.fill()
    })

    // Draw connection lines between nearby particles
    particlesRef.current.forEach((p1, i) => {
      particlesRef.current.slice(i + 1).forEach((p2) => {
        const dx = p1.x - p2.x
        const dy = p1.y - p2.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 100) {
          const opacity = (1 - distance / 100) * 0.08
          ctx.beginPath()
          ctx.strokeStyle = `rgba(6, 182, 212, ${opacity})`
          ctx.lineWidth = 0.5
          ctx.moveTo(p1.x, p1.y)
          ctx.lineTo(p2.x, p2.y)
          ctx.stroke()
        }
      })
    })

    // Draw glowing accent lines (horizontal thin lines)
    const accentLineCount = 3
    for (let i = 0; i < accentLineCount; i++) {
      const baseY = height * (0.25 + i * 0.25)
      const offsetY = Math.sin(timeRef.current * 0.7 + i * 2) * 20
      const opacity = 0.15 + Math.sin(timeRef.current + i) * 0.05

      const lineGradient = ctx.createLinearGradient(0, 0, width, 0)
      lineGradient.addColorStop(0, "transparent")
      lineGradient.addColorStop(0.2, `rgba(6, 182, 212, ${opacity * 0.3})`)
      lineGradient.addColorStop(0.5, `rgba(34, 211, 238, ${opacity})`)
      lineGradient.addColorStop(0.8, `rgba(14, 165, 233, ${opacity * 0.3})`)
      lineGradient.addColorStop(1, "transparent")

      ctx.beginPath()
      ctx.strokeStyle = lineGradient
      ctx.lineWidth = 1
      ctx.moveTo(0, baseY + offsetY)
      ctx.lineTo(width, baseY + offsetY)
      ctx.stroke()
    }

    // Subtle vignette effect
    const vignetteGradient = ctx.createRadialGradient(
      width / 2,
      height / 2,
      height * 0.3,
      width / 2,
      height / 2,
      width * 0.8
    )
    vignetteGradient.addColorStop(0, "transparent")
    vignetteGradient.addColorStop(1, "rgba(0, 0, 0, 0.4)")
    ctx.fillStyle = vignetteGradient
    ctx.fillRect(0, 0, width, height)

  }, [colors.cyan, colors.deepNavy, colors.navy])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const handleResize = () => {
      const dpr = window.devicePixelRatio || 1
      const rect = canvas.getBoundingClientRect()
      canvas.width = rect.width * dpr
      canvas.height = rect.height * dpr
      ctx.scale(dpr, dpr)
      canvas.style.width = `${rect.width}px`
      canvas.style.height = `${rect.height}px`
      initializeElements(rect.width, rect.height)
    }

    handleResize()
    window.addEventListener("resize", handleResize)

    const animate = () => {
      const rect = canvas.getBoundingClientRect()
      draw(ctx, rect.width, rect.height)
      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", handleResize)
      cancelAnimationFrame(animationRef.current)
    }
  }, [initializeElements, draw])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full"
      style={{ zIndex: 0 }}
    />
  )
}
